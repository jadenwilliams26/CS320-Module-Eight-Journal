/*
 * 
 * 
 * Jaden Williams
 * CS320
 * November 22nd, 2024
 * 
 *
 */

package Task;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

class TaskServiceTest {

	@AfterEach
	void tearDown() throws Exception {
		TaskService.tasks.clear();
	}

	@DisplayName("Add Task")
	@Test
	void testAddUniqueTask() {
        String id = "0";
      	String fullName = "John Doe";
        String description = "Valid description";
        
        TaskService tempTask = new TaskService();
        
        assertEquals(0, TaskService.tasks.size());
        
        tempTask.addUniqueTask(fullName, description);
       
		assertTrue(TaskService.tasks.containsKey(id));
		assertEquals(fullName, TaskService.tasks.get(id).getName());
		assertEquals(description, TaskService.tasks.get(id).getDescription());              
        
	}

	//Using addTask, add 3 contacts then remove task 1
	@DisplayName("Test removeTasks")			  
	@Test void testRemoveTask() {
				  
      	String fullName = "John Doe";
        String description = "Valid description";
		  
        TaskService tempTask = new TaskService();
        
        assertEquals(0, TaskService.tasks.size());

        tempTask.addUniqueTask(fullName, description);
        tempTask.addUniqueTask(fullName, description);
        tempTask.addUniqueTask(fullName, description);
		  
		assertEquals(3,TaskService.tasks.size());
		  
		tempTask.removeTasks("1");
		  
		assertEquals(2,TaskService.tasks.size());
		assertFalse(TaskService.tasks.containsKey("1"));
			 
	}

	//Create new task with ID 0, then update with valid ID
	@DisplayName("Test updateTask with valid ID")
	@Test
	void testUpdateTasks() {
		String id = "0";
		String fullName = "John Doe";
        String description = "Valid description";
		  
        TaskService tempTask = new TaskService();
        
        tempTask.addUniqueTask(fullName, description);

        tempTask.updateTasks("0", fullName, "New description");
        assertEquals("New description", TaskService.tasks.get(id).getDescription());
        assertEquals(fullName, TaskService.tasks.get(id).getName());
        
	}
	
	//Create new task with ID 0, then update with invalid ID
	@DisplayName("Test updateTask with invalid ID")
	@Test
	void testInvalidUpdateTasks() {
		String id = "0";
		String fullName = "John Doe";
        String description = "Valid description";
		  
        TaskService tempTask = new TaskService();
        
        tempTask.addUniqueTask(fullName, description);

        //1 is an invalid ID:
        tempTask.updateTasks("1", fullName, "New description");
        assertNotEquals("New description", TaskService.tasks.get(id).getDescription());
        assertEquals(fullName, TaskService.tasks.get(id).getName());
        
	}

}
