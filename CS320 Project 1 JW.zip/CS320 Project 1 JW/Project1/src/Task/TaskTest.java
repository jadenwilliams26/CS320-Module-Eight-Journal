/*
 * 
 * 
 * Jaden Williams
 * CS320
 * November 22nd, 2024
 * 
 * 
 */

package Task;

import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class TaskTest {

	//Valid input
	@DisplayName("Valid Input")
	@Test
	void validInput() {
		
        String id = "1";
      	String fullName = "John Doe";
        String description = "Valid description";

		
        Task tempTask = new Task(id, fullName, description);
        
		assertEquals(1, tempTask.getUniqueID());
		assertEquals(fullName, tempTask.getName());
		assertEquals(description, tempTask.getDescription());		
	}
	
	//Invalid too long input
	@DisplayName("Invalid input")
	@Test
	void invalidInput() {
		
        String id = "1";
      	String fullName = "John Doe";
        String description = "This description is far too long to be accepted as a valid input by the program.";
       
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	new Task(id, fullName, description);
        });		
	}
	
	//ID will be an invalid too long input
	@DisplayName("Invalid too long input")
	@Test
	void invalidIDInput() {
		
        String id = "0987654321123456";
      	String fullName = "John Doe";
        String description = "Valid description";
       
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	new Task(id, fullName, description);
        });       
	}
	//Set the ID to an invalid null input
	@DisplayName("Invalid null input")
	@Test
	void invalidNullInput() {
		
        String id = null;
      	String fullName = "John Doe";
        String description = "Valid description";
       
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	new Task(id, fullName, description);
        });       
	}
	
	//Test setFullName with valid input 
	@DisplayName("Test valid setName input")
	@Test
	public void testValidName() {
        String id = "1";
      	String fullName = "John Doe";
        String description = "Valid description";
		
        Task tempTask = new Task(id, fullName, description);  
        tempTask.setName("Jonathan Doe");        
        assertEquals("Jonathan Doe", tempTask.getName());
	}
	
	//Test setFullName with invalid null input
	@DisplayName("Test invalid null setName")
	@Test
	public void testNullName() {
        String id = "1";
      	String fullName = "John Doe";
        String description = "Valid description";
		
        Task tempTask = new Task(id, fullName, description);         
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            tempTask.setName(null); 
        });	
	}
	
	//Test the setFullName with invalid too long input 
	@DisplayName("Test invalid too long setName")
	@Test
	public void testLongName() {
        String id = "1";
      	String fullName = "John Doe";
        String description = "Valid description";
		
        Task tempTask = new Task(id, fullName, description);         
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            tempTask.setName("Johnathan No Name Should Be This Long Doe"); 
        });	
	}
	
	//Test setFullName with an empty string 
	@DisplayName("Test an invalid empty setName")
	@Test
	public void testEmptyName() {
        String id = "1";
      	String fullName = "John Doe";
        String description = "Valid description";
		
        Task tempTask = new Task(id, fullName, description);         
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            tempTask.setName(""); 
        });	
	}
	
	
	//Test setDescription with an empty string 
	@DisplayName("Test an invalid empty string")
	@Test
	public void testEmptyDescription() {
        String id = "1";
      	String fullName = "John Doe";
        String description = "";                 
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	new Task(id, fullName, description);; 
        });	
	}
	
	//Test setDescription with an invalid null input
	@DisplayName("Test an invalid null description")
	@Test
	public void testNullDescription() {
        String id = "1";
      	String fullName = "John Doe";
        String description = null;
		
        Task tempTask = new Task(id, fullName, "test");                
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            tempTask.setDescription(null); 
        });	
        
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
        	new Task(id, fullName, description);; 
        });	
        
	}
	

}
