/*
 * 
 * 
 * Jaden Williams
 * CS320
 * 11/27/2024
 * 
 * 
 */

package Appointment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import java.util.Date;
import java.util.Calendar;
import org.junit.jupiter.api.Test;

class AppointmentTest {


	//Tests for valid input
	@DisplayName("Test valid input")
	@Test
	void testAppointment() {
        String id = "1";
        Calendar c = Calendar.getInstance();
        String description = "Valid description";
        
      	c.set(Calendar.MONTH, 12);
      	c.set(Calendar.DATE, 01);
      	c.set(Calendar.YEAR, 2026);
      	
      	Date validDate = c.getTime();
        
        Appointment tempAppt = new Appointment(id, validDate, description);
        
        assertEquals(1, tempAppt.getUniqueID());
        assertEquals(validDate, tempAppt.getDate());
        assertEquals(description, tempAppt.getDescription());       
        
	}
	

	//Test an invalid, too long id input
	@DisplayName("Test invalid lengthy ID")
	@Test
	void testInvalidAppointment() {
        String id = "987654321123456";
      	Date date = new Date();
        String description = "Valid description";
               
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(id, date, description);
        });
        
        assertEquals("Invalid ID", exception.getMessage());
        
	}
	
	//Test an invalid null id input
	@DisplayName("Test invalid null id")
	@Test
	void testInvalidIDNull() {
        String id = null;
      	Date date = new Date();
        String description = "Valid description";
               
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(id, date, description);
        });
        
        assertEquals("Invalid ID", exception.getMessage());
        
	}
	
	//Test an invalid date set in the past
	@DisplayName("Test  invalid past date")
	@Test
	void testInvalidDate() {
        String id = "1";
        Calendar c = Calendar.getInstance();
      	String description = "Valid description";
      	
      	c.set(Calendar.MONTH, 12);
      	c.set(Calendar.DATE, 01);
      	c.set(Calendar.YEAR, 2001);
      	
      	Date invalidDate = c.getTime();
      	              
      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(id, invalidDate, description);
        });
      	
      	assertEquals("Invalid date", exception.getMessage());
        
	}
	
	//Test an invalid null date input
	@DisplayName("Test invalid null date")
	@Test
	void testNullDate() {
        String id = "1";
      	String description = "Valid description";    	
      	Date invalidDate = null;
      	
      	Calendar c = Calendar.getInstance();
      	
      	c.set(Calendar.MONTH, 12);
      	c.set(Calendar.DATE, 01);
      	c.set(Calendar.YEAR, 2026);
      	
      	Date validDate = c.getTime();
      	
      	Appointment tempAppt = new Appointment(id, validDate, description);      	
      	              
      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(id, invalidDate, description);
        });
      	
      	assertEquals("Invalid date", exception.getMessage());
      	
      	exception = assertThrows(IllegalArgumentException.class, () -> {
        	tempAppt.setDate(null);
        });
      	
      	assertEquals("Invalid date", exception.getMessage());
	}
	
	//Test an invalid, too long description
	@DisplayName("Test too lengthy description")
	@Test
	void testLongDescription() {
        String id = "1";
      	String description = "A description shall only be less than 50 characters before throwing an error";    	
      	Calendar c = Calendar.getInstance();
      	
      	c.set(Calendar.MONTH, 12);
      	c.set(Calendar.DATE, 01);
      	c.set(Calendar.YEAR, 2026);
      	
      	Date validDate = c.getTime();
      	
      	
      	Appointment tempAppt = new Appointment(id, validDate, "Test");
      	              
      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(id, validDate, description);
        });
      	
      	assertEquals("Invalid description", exception.getMessage());
      	
      	exception = assertThrows(IllegalArgumentException.class, () -> {
        	tempAppt.setDescription(description);
        });
      	
      	assertEquals("Invalid description", exception.getMessage());
	}
	
	//Tests for an invalid, null description
	@DisplayName("Test invalid null decription")
	@Test
	void testNullDescription() {
        String id = "1";
      	String description = null;    	
      	Calendar c = Calendar.getInstance();
      	
      	c.set(Calendar.MONTH, 12);
      	c.set(Calendar.DATE, 01);
      	c.set(Calendar.YEAR, 2026);
      	
      	Date validDate = c.getTime();
      	              
      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(id, validDate, description);
        });
      	
      	assertEquals("Invalid description", exception.getMessage());
	}
	
	//Tests for an invalid, empty description
	@DisplayName("Test empty description")
	@Test
	void testEmptyDescription() {
        String id = "1";
      	String description = "";    	
      	Calendar c = Calendar.getInstance();
      	
      	c.set(Calendar.MONTH, 12);
      	c.set(Calendar.DATE, 01);
      	c.set(Calendar.YEAR, 2026);
      	
      	Date validDate = c.getTime();
      	              
      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
        	new Appointment(id, validDate, description);
        });
      	
      	assertEquals("Invalid description", exception.getMessage());
	}
	
}
