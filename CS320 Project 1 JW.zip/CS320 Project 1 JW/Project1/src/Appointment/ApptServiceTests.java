/*
 * 
 * 
 * Jaden Williams
 * CS320
 * 11/27/2024
 * 
 * 
 */

package Appointment;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

class ApptServiceTests {

	@AfterEach
	void tearDown() throws Exception {
		AppointmentService.appointments.clear();
	}

	//Add an appointment
	@DisplayName("Add an Appointment")
	@Test
	void testAddUniqueAppt() {
		String id = "0";
		String description = "Valid description";
		Calendar c = Calendar.getInstance();

		c.set(Calendar.MONTH, 11);
		c.set(Calendar.DATE, 05);
		c.set(Calendar.YEAR, 2025);

		Date validDate = c.getTime();

		AppointmentService tempAppt = new AppointmentService();

		assertEquals(0, AppointmentService.appointments.size());

		tempAppt.addAppointment(validDate, description);

		assertTrue(AppointmentService.appointments.containsKey(id));
		assertEquals(validDate, AppointmentService.appointments.get(id).getDate());
		assertEquals(description, AppointmentService.appointments.get(id).getDescription());

	}
	
	//Add an invalid appointment with an empty description
	@DisplayName("Add invalid Appointment empty description")
	@Test
	void testAddEmptyDescription() {
		@SuppressWarnings("unused")
		String id = "0";
		//Invalid description:
		String description = "";
		Calendar c = Calendar.getInstance();

		c.set(Calendar.MONTH, 11);
		c.set(Calendar.DATE, 05);
		c.set(Calendar.YEAR, 2025);

		Date validDate = c.getTime();

      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
      		AppointmentService tempAppt = new AppointmentService();
      		tempAppt.addAppointment(validDate, description);
        });
      	
      	assertEquals("Invalid description", exception.getMessage());

	}
	
	//Add an invalid appointment with the description being null
	@DisplayName("Add invalid Appointment null description")
	@Test
	void testAddNullDescription() {
		@SuppressWarnings("unused")
		String id = "0";
		//Invalid description:
		String description = null; 
		Calendar c = Calendar.getInstance();

		c.set(Calendar.MONTH, 11);
		c.set(Calendar.DATE, 05);
		c.set(Calendar.YEAR, 2025);

		Date validDate = c.getTime();

      	IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
      		AppointmentService tempAppt = new AppointmentService();
      		tempAppt.addAppointment(validDate, description);
        });
      	
      	assertEquals("Invalid description", exception.getMessage());

	}

	//Add 3 contacts with addAppt, then delete contact id 1 and check that there is no object there
	@DisplayName("Test deleteAppt")
	@Test
	void testDeleteAppt() {

		@SuppressWarnings("unused")
		String id = "0";
		String description = "Valid description";
		Calendar c = Calendar.getInstance();

		c.set(Calendar.MONTH, 11);
		c.set(Calendar.DATE, 05);
		c.set(Calendar.YEAR, 2025);

		Date validDate = c.getTime();

		AppointmentService tempAppt = new AppointmentService();

		assertEquals(0, AppointmentService.appointments.size());

		tempAppt.addAppointment(validDate, description);
		tempAppt.addAppointment(validDate, description);
		tempAppt.addAppointment(validDate, description);

		assertEquals(3, AppointmentService.appointments.size());

		tempAppt.deleteAppointment("1");

		assertEquals(2, AppointmentService.appointments.size());
		assertFalse(AppointmentService.appointments.containsKey("1"));
		
		tempAppt.deleteAppointment("1");
		assertEquals(2, AppointmentService.appointments.size());

	}
}
