/*
 * 
 * 
 * Jaden Williams
 * CS320
 * 11/27/2024
 * 
 * 
 */

package Appointment;

import java.util.HashMap;
import java.util.Date;

public class AppointmentService {
	
int currentIDNum = 0;
	
	public static HashMap<String, Appointment> appointments = new HashMap<String, Appointment>();
	
	//Add appointment function
	public void addAppointment(Date _date, String _description) {

		String stringID = Integer.toString(currentIDNum);		
		Appointment tempAppointment = new Appointment (stringID, _date, _description);
		appointments.put(stringID, tempAppointment);	

		++currentIDNum;		
	}
	
	//Delete appointment function
	public void deleteAppointment(String _ID) {
		
		if(appointments.containsKey(_ID)) {			
			appointments.remove(_ID);
		}		
	}
}
